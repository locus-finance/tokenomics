module.exports = (task) => {
  require("./tasks/manual/autocracy/errorIncident/migrateBalancesViaMintBurn")(task);
  require("./tasks/manual/autocracy/errorIncident/restoreDeployerLocusBalance")(task);
  require("./tasks/manual/autocracy/errorIncident/personalTreatment")(task);
  require("./tasks/manual/autocracy/errorIncident/forceStakeAndMint")(task);
  require("./tasks/manual/autocracy/errorIncident/distributeRemainingRewards")(task);
  require("./tasks/manual/autocracy/errorIncident/clearRemainingWithdrawalsQueue")(task);

  require("./tasks/utils/errorIncident/collectStHoldersDataForIncident")(task);
  require("./tasks/utils/errorIncident/collectWithdrawSendingsDequeIntoCSV")(task);
  require("./tasks/utils/errorIncident/collectUsersPreErrorIntoCSV")(task);
  require("./tasks/manual/observe/errorIncident/collectStLocusBalancesAndEarned")(task);
}